async function loadCurrentUser() {
  try {
    const response = await fetch("/api/me", { credentials: "include" });
    if (!response.ok) {
      return { loggedIn: false };
    }
    return await response.json();
  } catch {
    return { loggedIn: false };
  }
}

function buildLoginRedirect(plan) {
  const nextUrl = `/pages/order.html?plan=${encodeURIComponent(plan)}`;
  return `/pages/login.html?next=${encodeURIComponent(nextUrl)}`;
}

async function initPricingButtons() {
  const buttons = document.querySelectorAll(".pricing-button[data-plan]");
  if (!buttons.length) {
    return;
  }

  const user = await loadCurrentUser();

  buttons.forEach((button) => {
    button.addEventListener("click", (event) => {
      event.preventDefault();
      const plan = button.getAttribute("data-plan") || "";
      if (!user.loggedIn) {
        window.location.href = buildLoginRedirect(plan);
        return;
      }
      window.location.href = `/pages/order.html?plan=${encodeURIComponent(plan)}`;
    });
  });
}

document.addEventListener("DOMContentLoaded", initPricingButtons);
