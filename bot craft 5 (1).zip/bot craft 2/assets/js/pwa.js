if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js').catch(() => {
      console.warn('Service Worker registration failed');
    });
  });
}

let deferredInstallPrompt = null;
window.addEventListener('beforeinstallprompt', (event) => {
  event.preventDefault();
  deferredInstallPrompt = event;
  console.log('PWA install prompt ready');
});

window.addEventListener('appinstalled', () => {
  console.log('PWA installed');
  deferredInstallPrompt = null;
});
