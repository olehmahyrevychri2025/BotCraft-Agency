async function getCurrentUser() {
  try {
    const response = await fetch("/api/me", { credentials: "include" });
    if (!response.ok) {
      return { loggedIn: false, username: null };
    }
    return await response.json();
  } catch {
    return { loggedIn: false, username: null };
  }
}

function getPostAuthRedirectUrl() {
  const params = new URLSearchParams(window.location.search);
  const next = params.get("next");
  return next || "/pages/home.html";
}

function updateNavbar(user) {
  const links = document.querySelectorAll("[data-auth-link]");
  links.forEach((link) => {
    const guestText = link.getAttribute("data-guest-text") || "Реєстрація";
    const guestHref = link.getAttribute("data-guest-href") || link.getAttribute("href") || "#";
    const nav = link.closest("nav");
    if (!nav) {
      return;
    }

    let logoutLink = nav.querySelector("[data-logout-link]");
    if (!logoutLink) {
      logoutLink = document.createElement("a");
      logoutLink.setAttribute("href", "#");
      logoutLink.setAttribute("data-logout-link", "true");
      logoutLink.className = "auth-logout-link";
      logoutLink.textContent = "Вийти";
      nav.appendChild(logoutLink);
    }

    logoutLink.onclick = async (event) => {
      event.preventDefault();
      await fetch("/api/logout", {
        method: "POST",
        credentials: "include",
      });
      window.location.reload();
    };

    if (user.loggedIn && user.username) {
      link.textContent = user.username;
      link.setAttribute("href", "#");
      link.classList.remove("active");
      logoutLink.style.display = "inline";
      return;
    }

    link.textContent = guestText;
    link.setAttribute("href", guestHref);
    logoutLink.style.display = "none";
  });
}

function showMessage(elementId, text, isError) {
  const node = document.getElementById(elementId);
  if (!node) {
    return;
  }
  node.textContent = text;
  node.className = `form-message ${isError ? 'error' : 'success'} show`;
  
  // Auto-hide after 5 seconds
  setTimeout(() => {
    node.classList.remove('show');
  }, 5000);
}

async function handleLogin() {
  const form = document.getElementById("login-form");
  if (!form) {
    return;
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const username = document.getElementById("login-username")?.value?.trim() || "";
    const password = document.getElementById("login-password")?.value || "";

    const response = await fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ username, password }),
    });

    const data = await response.json();
    if (!response.ok || !data.ok) {
      showMessage("login-message", data.message || "Не вдалося увійти.", true);
      return;
    }

    showMessage("login-message", "Вхід успішний.", false);
    window.location.href = getPostAuthRedirectUrl();
  });
}

async function handleRegister() {
  const form = document.getElementById("register-form");
  if (!form) {
    return;
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const fullName = document.getElementById("register-fullname")?.value?.trim() || "";
    const username = document.getElementById("register-username")?.value?.trim() || "";
    const password = document.getElementById("register-password")?.value || "";
    const passwordRepeat = document.getElementById("register-password-repeat")?.value || "";

    if (password !== passwordRepeat) {
      showMessage("register-message", "Паролі не співпадають.", true);
      return;
    }

    const response = await fetch("/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ fullName, username, password }),
    });

    const data = await response.json();
    if (!response.ok || !data.ok) {
      showMessage("register-message", data.message || "Не вдалося зареєструватися.", true);
      return;
    }

    showMessage("register-message", "Реєстрація успішна.", false);
    window.location.href = getPostAuthRedirectUrl();
  });
}

async function initAuth() {
  const user = await getCurrentUser();
  updateNavbar(user);
  handleLogin();
  handleRegister();
  initBurgerMenu();
  initFormValidation();
}

function initFormValidation() {
  // Real-time validation for login form
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    const usernameInput = document.getElementById('login-username');
    const passwordInput = document.getElementById('login-password');
    
    [usernameInput, passwordInput].forEach(input => {
      if (input) {
        input.addEventListener('blur', () => validateField(input));
        input.addEventListener('input', () => clearFieldError(input));
      }
    });
  }

  // Real-time validation for register form
  const registerForm = document.getElementById('register-form');
  if (registerForm) {
    const fullnameInput = document.getElementById('register-fullname');
    const usernameInput = document.getElementById('register-username');
    const passwordInput = document.getElementById('register-password');
    const passwordRepeatInput = document.getElementById('register-password-repeat');
    
    [fullnameInput, usernameInput, passwordInput, passwordRepeatInput].forEach(input => {
      if (input) {
        input.addEventListener('blur', () => validateField(input));
        input.addEventListener('input', () => clearFieldError(input));
      }
    });
  }
}

function validateField(input) {
  const value = input.value.trim();
  let isValid = true;
  let message = '';

  switch (input.id) {
    case 'register-fullname':
      if (value.length < 2) {
        isValid = false;
        message = 'Ім\'я має містити щонайменше 2 символи';
      }
      break;
    case 'register-username':
    case 'login-username':
      if (value.length < 3) {
        isValid = false;
        message = 'Логін має містити щонайменше 3 символи';
      }
      break;
    case 'register-password':
    case 'login-password':
      if (value.length < 6) {
        isValid = false;
        message = 'Пароль має містити щонайменше 6 символів';
      }
      break;
    case 'register-password-repeat':
      const password = document.getElementById('register-password')?.value || '';
      if (value !== password) {
        isValid = false;
        message = 'Паролі не співпадають';
      }
      break;
  }

  if (!isValid) {
    showFieldError(input, message);
  } else {
    clearFieldError(input);
  }

  return isValid;
}

function showFieldError(input, message) {
  input.style.borderColor = 'rgba(239, 68, 68, 0.5)';
  input.style.boxShadow = '0 0 0 3px rgba(239, 68, 68, 0.1)';
  
  let errorElement = input.parentNode.querySelector('.field-error');
  if (!errorElement) {
    errorElement = document.createElement('div');
    errorElement.className = 'field-error';
    input.parentNode.appendChild(errorElement);
  }
  errorElement.textContent = message;
  errorElement.style.display = 'block';
}

function clearFieldError(input) {
  input.style.borderColor = '';
  input.style.boxShadow = '';
  
  const errorElement = input.parentNode.querySelector('.field-error');
  if (errorElement) {
    errorElement.style.display = 'none';
  }
}

function initBurgerMenu() {
  const burger = document.querySelector('.burger-menu');
  const nav = document.querySelector('.site-nav');
  
  if (burger && nav) {
    burger.addEventListener('click', () => {
      burger.classList.toggle('active');
      nav.classList.toggle('mobile-menu-open');
    });
    
    // Close menu when clicking on a link
    const navLinks = nav.querySelectorAll('nav a');
    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        burger.classList.remove('active');
        nav.classList.remove('mobile-menu-open');
      });
    });
    
    // Close menu when clicking outside
    document.addEventListener('click', (event) => {
      if (!nav.contains(event.target) && nav.classList.contains('mobile-menu-open')) {
        burger.classList.remove('active');
        nav.classList.remove('mobile-menu-open');
      }
    });
  }
}

document.addEventListener("DOMContentLoaded", initAuth);