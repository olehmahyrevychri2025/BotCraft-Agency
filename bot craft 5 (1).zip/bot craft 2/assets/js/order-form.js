async function getOrderUser() {
  try {
    const response = await fetch("/api/me", { credentials: "include" });
    if (!response.ok) {
      return { loggedIn: false };
    }
    return await response.json();
  } catch {
    return { loggedIn: false };
  }
}

function orderMessage(text, isError = false) {
  const node = document.getElementById("order-message");
  if (!node) {
    return;
  }
  node.textContent = text;
  node.style.color = isError ? "#ffb0b0" : "#a8f0ff";
}

function fillPlanFromQuery() {
  const params = new URLSearchParams(window.location.search);
  const plan = params.get("plan") || "";
  const planInput = document.getElementById("order-plan");
  if (planInput && plan) {
    planInput.value = plan;
  }
}

async function initOrderForm() {
  const user = await getOrderUser();
  if (!user.loggedIn) {
    const nextUrl = `${window.location.pathname}${window.location.search}`;
    window.location.href = `/pages/login.html?next=${encodeURIComponent(nextUrl)}`;
    return;
  }

  fillPlanFromQuery();

  const form = document.getElementById("orderForm");
  if (!form) {
    return;
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    const payload = {
      projectName: document.getElementById("name")?.value?.trim() || "",
      botType: document.getElementById("type")?.value?.trim() || "",
      description: document.getElementById("desc")?.value?.trim() || "",
      budget: document.getElementById("budget")?.value?.trim() || "",
      timeline: document.getElementById("time")?.value?.trim() || "",
      selectedPlan: document.getElementById("order-plan")?.value?.trim() || "",
    };

    const response = await fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(payload),
    });

    const data = await response.json();
    if (!response.ok || !data.ok) {
      orderMessage(data.message || "Не вдалося опублікувати замовлення.", true);
      return;
    }

    orderMessage("Замовлення опубліковано.");
    form.reset();
    fillPlanFromQuery();
  });
}

document.addEventListener("DOMContentLoaded", initOrderForm);
