let lastMessageId = 0;
let pollingTimer = null;

function supportEl(id) {
  return document.getElementById(id);
}

function setStatus(text, isError = false) {
  const status = supportEl("support-chat-status");
  if (!status) {
    return;
  }
  status.textContent = text;
  status.style.color = isError ? "#ff9d9d" : "#95dcff";
}

function appendMessage(message) {
  const list = supportEl("support-chat-messages");
  if (!list) {
    return;
  }

  const row = document.createElement("div");
  row.className = `chat-row ${message.sender === "user" ? "from-user" : "from-admin"}`;

  const bubble = document.createElement("div");
  bubble.className = "chat-bubble";
  bubble.textContent = message.text;

  row.appendChild(bubble);
  list.appendChild(row);
  list.scrollTop = list.scrollHeight;
}

async function fetchMessages() {
  const response = await fetch(`/api/support/messages?after_id=${lastMessageId}`, {
    credentials: "include",
  });

  if (response.status === 401) {
    setStatus("Щоб писати в підтримку, увійдіть у свій акаунт.", true);
    return;
  }

  const payload = await response.json();
  if (!response.ok || !payload.ok) {
    setStatus(payload.message || "Не вдалося завантажити чат.", true);
    return;
  }

  const messages = payload.messages || [];
  messages.forEach((message) => {
    appendMessage(message);
    lastMessageId = Math.max(lastMessageId, Number(message.id) || 0);
  });
}

async function sendMessage(text) {
  const response = await fetch("/api/support/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify({ text }),
  });

  const payload = await response.json();
  if (!response.ok || !payload.ok) {
    throw new Error(payload.message || "Не вдалося надіслати повідомлення.");
  }
}

function initSupportChat() {
  const form = supportEl("support-chat-form");
  const input = supportEl("support-chat-input");
  const list = supportEl("support-chat-messages");

  if (!form || !input || !list) {
    return;
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const text = input.value.trim();
    if (!text) {
      return;
    }

    try {
      await sendMessage(text);
      input.value = "";
      setStatus("Повідомлення надіслано.");
      await fetchMessages();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Помилка надсилання.";
      setStatus(message, true);
    }
  });

  fetchMessages();
  pollingTimer = window.setInterval(fetchMessages, 2500);

  window.addEventListener("beforeunload", () => {
    if (pollingTimer !== null) {
      window.clearInterval(pollingTimer);
    }
  });
}

document.addEventListener("DOMContentLoaded", initSupportChat);
