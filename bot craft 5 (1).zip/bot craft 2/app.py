import os
import threading
import time
from typing import Any

from flask import Flask, jsonify, redirect, request, session
import mysql.connector
from mysql.connector import Error
import requests
from dotenv import load_dotenv
from werkzeug.security import check_password_hash, generate_password_hash


load_dotenv()


app = Flask(__name__, static_folder=".", static_url_path="")
app.config["SECRET_KEY"] = os.getenv("FLASK_SECRET_KEY", "change-this-secret-in-production")

TELEGRAM_TOKEN = os.getenv("TG_BOT_TOKEN", "").strip()
TELEGRAM_ADMIN_CHAT_ID = os.getenv("TG_ADMIN_CHAT_ID", "").strip()
TELEGRAM_API_BASE = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}" if TELEGRAM_TOKEN else ""

_telegram_offset = 0
_telegram_worker_started = False


def get_db_connection() -> mysql.connector.MySQLConnection:
    return mysql.connector.connect(
        host=os.getenv("DB_HOST", "127.0.0.1"),
        port=int(os.getenv("DB_PORT", "3306")),
        user=os.getenv("DB_USER", "root"),
        password=os.getenv("DB_PASSWORD", ""),
        database=os.getenv("DB_NAME", "bot_craft"),
        autocommit=True,
    )


def get_json() -> dict[str, Any]:
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


def get_current_user() -> tuple[int | None, str | None]:
    user_id = session.get("user_id")
    username = session.get("username")
    if isinstance(user_id, int) and isinstance(username, str):
        return user_id, username
    return None, None


def telegram_enabled() -> bool:
    return bool(TELEGRAM_API_BASE and TELEGRAM_ADMIN_CHAT_ID)


def send_telegram_message(text: str) -> None:
    if not telegram_enabled():
        return

    try:
        requests.post(
            f"{TELEGRAM_API_BASE}/sendMessage",
            json={"chat_id": TELEGRAM_ADMIN_CHAT_ID, "text": text},
            timeout=10,
        )
    except requests.RequestException:
        # Do not fail the main request if Telegram is temporarily unavailable.
        pass


def save_support_message(user_id: int, sender: str, text: str) -> None:
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        cursor = connection.cursor()
        cursor.execute(
            "INSERT INTO support_messages (user_id, sender, body) VALUES (%s, %s, %s)",
            (user_id, sender, text),
        )
    finally:
        if cursor is not None:
            cursor.close()
        if connection is not None and connection.is_connected():
            connection.close()


def save_order(
    user_id: int,
    selected_plan: str,
    project_name: str,
    bot_type: str,
    description: str,
    budget: str,
    timeline: str,
) -> None:
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        cursor = connection.cursor()
        cursor.execute(
            """
            INSERT INTO bot_orders (user_id, selected_plan, project_name, bot_type, description, budget, timeline)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """,
            (user_id, selected_plan, project_name, bot_type, description, budget, timeline),
        )
    finally:
        if cursor is not None:
            cursor.close()
        if connection is not None and connection.is_connected():
            connection.close()


def fetch_telegram_updates() -> list[dict[str, Any]]:
    global _telegram_offset

    if not telegram_enabled():
        return []

    try:
        response = requests.get(
            f"{TELEGRAM_API_BASE}/getUpdates",
            params={"timeout": 20, "offset": _telegram_offset + 1},
            timeout=30,
        )
        response.raise_for_status()
        payload = response.json()
        if not payload.get("ok"):
            return []
        updates = payload.get("result", [])
        if updates:
            _telegram_offset = max(update.get("update_id", _telegram_offset) for update in updates)
        return updates
    except (requests.RequestException, ValueError):
        return []


def sync_telegram_offset_to_latest() -> None:
    global _telegram_offset

    if not telegram_enabled():
        return

    try:
        response = requests.get(
            f"{TELEGRAM_API_BASE}/getUpdates",
            params={"timeout": 0},
            timeout=10,
        )
        response.raise_for_status()
        payload = response.json()
        if payload.get("ok"):
            updates = payload.get("result", [])
            if updates:
                _telegram_offset = max(update.get("update_id", _telegram_offset) for update in updates)
    except (requests.RequestException, ValueError):
        return


def find_user_id_by_username(username: str) -> int | None:
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT id FROM users WHERE username = %s LIMIT 1", (username,))
        user = cursor.fetchone()
        return int(user["id"]) if user else None
    except Error:
        return None
    finally:
        if cursor is not None:
            cursor.close()
        if connection is not None and connection.is_connected():
            connection.close()


def process_telegram_update(update: dict[str, Any]) -> None:
    message = update.get("message") or {}
    text = str(message.get("text") or "").strip()
    chat = message.get("chat") or {}
    incoming_chat_id = str(chat.get("id", ""))

    if incoming_chat_id != TELEGRAM_ADMIN_CHAT_ID:
        return
    if not text.startswith("/reply "):
        send_telegram_message("Формат відповіді: /reply username текст повідомлення")
        return

    parts = text.split(maxsplit=2)
    if len(parts) < 3:
        send_telegram_message("Помилка формату. Приклад: /reply ivan Привіт, чим допомогти?")
        return

    username = parts[1].lstrip("@").strip()
    reply_text = parts[2].strip()
    if not username or not reply_text:
        send_telegram_message("Помилка формату. Приклад: /reply ivan Привіт, чим допомогти?")
        return

    user_id = find_user_id_by_username(username)
    if user_id is None:
        send_telegram_message(f"Користувач @{username} не знайдений.")
        return

    try:
        save_support_message(user_id, "admin", reply_text)
        send_telegram_message(f"Відправлено @{username}: {reply_text}")
    except Error:
        send_telegram_message("Не вдалося зберегти відповідь у базу.")


def telegram_worker() -> None:
    while True:
        updates = fetch_telegram_updates()
        for update in updates:
            process_telegram_update(update)
        time.sleep(1.5)


def start_telegram_worker_once() -> None:
    global _telegram_worker_started

    if _telegram_worker_started or not telegram_enabled():
        return

    sync_telegram_offset_to_latest()

    worker = threading.Thread(target=telegram_worker, daemon=True)
    worker.start()
    _telegram_worker_started = True


@app.before_request
def ensure_telegram_worker_running() -> None:
    start_telegram_worker_once()


@app.get("/")
def home() -> Any:
    return redirect("/pages/home.html")


@app.get("/api/me")
def me() -> Any:
    user_id, username = get_current_user()
    if username:
        return jsonify({"loggedIn": True, "username": username, "userId": user_id})
    return jsonify({"loggedIn": False, "username": None})


@app.post("/api/register")
def register() -> Any:
    payload = get_json()
    full_name = str(payload.get("fullName", "")).strip()
    username = str(payload.get("username", "")).strip()
    password = str(payload.get("password", ""))

    if len(full_name) < 2:
        return jsonify({"ok": False, "message": "Вкажіть ім'я (мінімум 2 символи)."}), 400
    if len(username) < 3:
        return jsonify({"ok": False, "message": "Логін має містити щонайменше 3 символи."}), 400
    if len(password) < 6:
        return jsonify({"ok": False, "message": "Пароль має містити щонайменше 6 символів."}), 400

    password_hash = generate_password_hash(password)

    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute(
            "INSERT INTO users (full_name, username, password_hash) VALUES (%s, %s, %s)",
            (full_name, username, password_hash),
        )

        user_id = cursor.lastrowid
        session["user_id"] = user_id
        session["username"] = username

        return jsonify({"ok": True, "username": username})
    except Error as exc:
        if getattr(exc, "errno", None) == 1062:
            return jsonify({"ok": False, "message": "Такий логін вже зайнятий."}), 409
        return jsonify({"ok": False, "message": "Помилка сервера під час реєстрації."}), 500
    finally:
        if cursor is not None:
            cursor.close()
        if connection is not None and connection.is_connected():
            connection.close()


@app.post("/api/login")
def login() -> Any:
    payload = get_json()
    username = str(payload.get("username", "")).strip()
    password = str(payload.get("password", ""))

    if not username or not password:
        return jsonify({"ok": False, "message": "Вкажіть логін і пароль."}), 400

    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute(
            "SELECT id, username, password_hash FROM users WHERE username = %s LIMIT 1",
            (username,),
        )
        user = cursor.fetchone()

        if user is None or not check_password_hash(user["password_hash"], password):
            return jsonify({"ok": False, "message": "Неправильний логін або пароль."}), 401

        session["user_id"] = user["id"]
        session["username"] = user["username"]

        return jsonify({"ok": True, "username": user["username"]})
    except Error:
        return jsonify({"ok": False, "message": "Помилка сервера під час входу."}), 500
    finally:
        if cursor is not None:
            cursor.close()
        if connection is not None and connection.is_connected():
            connection.close()


@app.post("/api/logout")
def logout() -> Any:
    session.clear()
    return jsonify({"ok": True})


@app.get("/api/support/messages")
def get_support_messages() -> Any:
    user_id, _ = get_current_user()
    if user_id is None:
        return jsonify({"ok": False, "message": "Потрібно увійти в акаунт."}), 401

    try:
        after_id = int(request.args.get("after_id", "0"))
    except ValueError:
        after_id = 0

    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute(
            """
            SELECT id, sender, body, created_at
            FROM support_messages
            WHERE user_id = %s AND id > %s
            ORDER BY id ASC
            LIMIT 100
            """,
            (user_id, after_id),
        )
        messages = cursor.fetchall()
        normalized = [
            {
                "id": int(row["id"]),
                "sender": row["sender"],
                "text": row["body"],
                "createdAt": row["created_at"].isoformat() if row.get("created_at") else None,
            }
            for row in messages
        ]
        return jsonify({"ok": True, "messages": normalized})
    except Error:
        return jsonify({"ok": False, "message": "Не вдалося завантажити повідомлення."}), 500
    finally:
        if cursor is not None:
            cursor.close()
        if connection is not None and connection.is_connected():
            connection.close()


@app.post("/api/support/messages")
def post_support_message() -> Any:
    user_id, username = get_current_user()
    if user_id is None or username is None:
        return jsonify({"ok": False, "message": "Потрібно увійти в акаунт."}), 401

    payload = get_json()
    text = str(payload.get("text", "")).strip()

    if len(text) < 1:
        return jsonify({"ok": False, "message": "Введіть повідомлення."}), 400
    if len(text) > 1500:
        return jsonify({"ok": False, "message": "Повідомлення занадто довге (макс. 1500)."}), 400

    try:
        save_support_message(user_id, "user", text)
    except Error:
        return jsonify({"ok": False, "message": "Не вдалося зберегти повідомлення."}), 500

    send_telegram_message(
        "\n".join(
            [
                "Нове повідомлення з сайту:",
                f"Користувач: @{username}",
                f"Текст: {text}",
                "",
                "Щоб відповісти: /reply username ваш_текст",
            ]
        )
    )

    return jsonify({"ok": True})


@app.post("/api/orders")
def create_order() -> Any:
    user_id, username = get_current_user()
    if user_id is None or username is None:
        return jsonify({"ok": False, "message": "Потрібно увійти в акаунт."}), 401

    payload = get_json()
    selected_plan = str(payload.get("selectedPlan", "")).strip()
    project_name = str(payload.get("projectName", "")).strip()
    bot_type = str(payload.get("botType", "")).strip()
    description = str(payload.get("description", "")).strip()
    budget = str(payload.get("budget", "")).strip()
    timeline = str(payload.get("timeline", "")).strip()

    if not all([selected_plan, project_name, bot_type, description, budget, timeline]):
        return jsonify({"ok": False, "message": "Заповніть усі поля замовлення."}), 400

    try:
        save_order(user_id, selected_plan, project_name, bot_type, description, budget, timeline)
    except Error:
        return jsonify({"ok": False, "message": "Не вдалося зберегти замовлення."}), 500

    send_telegram_message(
        "\n".join(
            [
                "Нове замовлення на бота:",
                f"Користувач: @{username}",
                f"Тариф: {selected_plan}",
                f"Назва проекту: {project_name}",
                f"Тип бота: {bot_type}",
                f"Опис: {description}",
                f"Бюджет: {budget}",
                f"Термін: {timeline}",
            ]
        )
    )

    return jsonify({"ok": True})


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=3000)