const CACHE_NAME = 'tg-bot-cache-v1';
const ASSETS = [
  '/pages/home.html',
  '/pages/about.html',
  '/pages/pricing.html',
  '/pages/support.html',
  '/pages/login.html',
  '/pages/register.html',
  '/pages/order.html',
  '/assets/css/main.css',
  '/assets/js/auth.js',
  '/assets/img/logo.webp',
  '/assets/img/home-bot.png',
  '/assets/img/telegram.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
      )
    )
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        return cachedResponse;
      }
      return fetch(event.request).catch(() => {
        if (event.request.destination === 'document') {
          return caches.match('/pages/home.html');
        }
      });
    })
  );
});
